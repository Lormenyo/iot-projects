<?php
//local
$servername= "localhost";
$username="root";
$password="";
$dbname="iotlab4";

$con = mysqli_connect($servername,$username,$password,$dbname) or die ("could not connect database");

?>

