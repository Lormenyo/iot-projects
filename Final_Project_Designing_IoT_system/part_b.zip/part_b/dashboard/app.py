from application.routes import *




if __name__ == "__main__":
    app.run()
